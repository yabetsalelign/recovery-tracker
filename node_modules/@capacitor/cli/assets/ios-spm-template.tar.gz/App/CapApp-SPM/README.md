# CapApp-SPM

This SPM is used to host SPM dependencies for you Capacitor project

Do not modify the contents of it or there may be unintended consequences.
